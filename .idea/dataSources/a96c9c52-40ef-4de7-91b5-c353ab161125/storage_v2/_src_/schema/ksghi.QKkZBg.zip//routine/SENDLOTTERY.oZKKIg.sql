create PROCEDURE "SENDLOTTERY" (activityId in varchar2,lotteryType in varchar2) is
lottery_cursor sys_refcursor;
user_lottery_cursor sys_refcursor;
TYPE RECORD_LOTTERY IS RECORD(
record_id varchar2(50),
record_lotteryType varchar2(50)
);
type RECORD_USERLOTTERY IS RECORD(
v_id user_activity_lottery.id%type,
v_user_info_id user_activity_lottery.user_info_id%type,
v_activity_id user_activity_lottery.activity_id%type,
v_activity_lottery_id user_activity_lottery.activity_lottery_id%type,
v_status user_activity_lottery.status%type,
v_use_time user_activity_lottery.use_time%type,
v_remark user_activity_lottery.remark%type,
v_create_time user_activity_lottery.create_time%type,
v_data_status user_activity_lottery.data_status%type,
v_product_id user_activity_lottery.product_id%type,
v_tender_id user_activity_lottery.tender_id%type,
v_expired_time user_activity_lottery.expired_time%type
);
v_lottery RECORD_LOTTERY;
v_userActivityLottery  RECORD_USERLOTTERY;
mysql varchar2(1000);
addlotterySql varchar2(2000);
selectLotterySql  varchar2(2000);
remark varchar2(1000);
expiredTime varchar2(19);
lotteryNum number(6);
begin
  mysql := 'select t.id,t.type from activity_lottery t where  1 = 1  and t.data_status =''valid''';
  if activityId is not null then
     mysql:=mysql ||  ' and t.activity_id = '|| activityId ;
  end if;
  /

