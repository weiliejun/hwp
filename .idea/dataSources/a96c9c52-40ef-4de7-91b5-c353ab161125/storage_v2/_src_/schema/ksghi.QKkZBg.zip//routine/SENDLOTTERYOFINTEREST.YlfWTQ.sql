create PROCEDURE "SENDLOTTERYOFINTEREST" (activityId in varchar2,lotteryType in varchar2) is
lottery_cursor sys_refcursor;
TYPE RECORD_LOTTERY IS RECORD(
record_id varchar2(50),
record_lotteryType varchar2(50)
);
v_lottery RECORD_LOTTERY;

mysql varchar2(1000);
addlotterySql varchar2(2000);
v_remark varchar2(1000);
expiredTime varchar2(19);
lotteryNum number(6);
begin
  mysql := 'select t.id,t.type from activity_lottery t where  1 = 1  and t.data_status =''valid''';
  if activityId is not null then
     mysql:=mysql ||  ' and t.activity_id = '''|| activityId ;
  end if;
  /

