create PROCEDURE             DistributeAveragelyForGroup
(momeny number,userCount number,administratorUserID number,administratorsGroupID number,currentGroupID number,isChildDept number,dayear number) as

/******************************************************************************
   NAME:       CentralizedPlacementFunds
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2007-6-17   zhaoyuyang       1. Created this procedure.

   NOTES: ？？？？？？？？？侭？？

******************************************************************************/
groupNum number :=0; --？？？？id？？？？？？е？？？？？？

--？α？3 ？？？？？？？？？？id
    cursor rs_cursor1 is
           SELECT tgid FROM tgroup where tgid != currentGroupID CONNECT BY PRIOR tgid = parentid START WITH tgid = currentGroupID;
    rs1 rs_cursor1%rowtype;

BEGIN

     SELECT count(tgid) into groupNum FROM tgroup where tgid != currentGroupID CONNECT BY PRIOR tgid = parentid START WITH tgid = currentGroupID;
     update distributeaccount set balance = balance - (groupNum*momeny)
     where entitytype = 2 and entityid = administratorsGroupID and dayear = dayear;

     INSERT INTO Distributeaccountlist
     (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
     values
     (1,2,administratorsGroupID,1,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'？？？？？？？--？？？？？--？？？？？？？',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

     INSERT INTO Distributeaccountlist
     (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
     values
     (1,2,administratorsGroupID,2,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'？？？？？？？--？？？？？--？？？？？？？',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

    for rs1 in rs_cursor1
      loop
       update distributeaccount set totalamount = totalamount+momeny,balance = balance + momeny
       where entitytype = 2 and entityid = rs1.tgid and dayear = dayear;

       INSERT INTO Distributeaccountlist
              (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
       values
             (1,2,rs1.tgid,1,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'？？？？？？？？？？？？？？？？洢？？？？',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

      end loop;
     /

