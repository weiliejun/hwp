create FUNCTION             GETGROUPIDS_FUNC

(

iGroup_id  in NUMBER

)

RETURN VARCHAR2

IS

    CURSOR cs IS SELECT ID,parentid,LEVEL FROM tgroup  WHERE parentid>0  CONNECT BY ID = PRIOR parentid START WITH ID = iGroup_id ORDER BY LEVEL;

    strGroupids  VARCHAR2(200);

BEGIN

    strGroupids := ',,'||TO_CHAR(iGroup_id)||',,';

    FOR acct IN cs LOOP

    strGroupids :=  ',,' || TO_CHAR(acct.parentid) || strGroupids;

    END LOOP;
    /

