create PROCEDURE             CentralizedPlacementFunds
(momeny number,userCount number,administratorUserID number,administratorsGroupID number,currentGroupID number,isChildDept number,dayear number) as

/******************************************************************************
   NAME:       CentralizedPlacementFunds
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2007-6-17   zhaoyuyang       1. Created this procedure.

   NOTES: ？？？？侭？？

******************************************************************************/
userNumberTemp number :=0; --？？？？？？？？？？？？？？？？？？？？？？？


--？α？4 ？？？？？？？？？？？？？е？？？？？
    cursor rs_cursor4 is
           select da.entityid as tgid from distributeaccount da where da.entitytype = 2 and da.dayear = dayear and da.accountisdelete = 0;
    rs4 rs_cursor4%rowtype;

--？α？6？？？？？？？？？？？？？е？？？？？？？ ？？？？？？？？？？
  	cursor rs_cursor6 is
           select da.entityid as tuid from distributeaccount da ,tuser tu
           where da.entitytype = 1 and da.dayear = dayear and tu.tuid = da.entityid and tu.deptid = currentGroupID;
    rs6 rs_cursor6%rowtype;

--？α？7？？？？？？？？？？？？？е？？？？？？？ ？？？？？？？？
  	cursor rs_cursor7 is
         select tu.tuid
         from distributeaccount da,(SELECT tgid FROM tgroup CONNECT BY PRIOR tgid = parentid START WITH tgid = currentGroupID) tempgroup, tuser tu
         where da.entitytype = 1 and da.entityid = tu.tuid and tempgroup.tgid =tu.deptid and da.dayear = dayear;
    rs7 rs_cursor7%rowtype;

BEGIN


     update distributeaccount set balance = balance - (userCount*momeny)
     where entitytype = 2 and entityid = administratorsGroupID and dayear = dayear;

     INSERT INTO Distributeaccountlist
     (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
     values
     (1,2,administratorsGroupID,1,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'？？？？？？？--？？--？？？？？？？',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

     INSERT INTO Distributeaccountlist
     (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
     values
     (1,2,administratorsGroupID,2,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'？？？？？？？--？？--？？？？？？？',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

    if isChildDept = 0 then
        --？？？？？？侭？？
       	for rs6 in rs_cursor6
           loop
                 update distributeaccount set totalamount = totalamount+momeny,balance = balance + momeny
                 where entitytype = 1 and entityid = rs6.tuid and dayear = dayear;

                 INSERT INTO Distributeaccountlist
                        (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                 values
                       (1,1,rs6.tuid,1,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'？？？？？？？--？？--？？？？？？？？？洢？？？？',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

    	     end loop;
        /

