create view VTUSERTRAININGACTIVITY as
SELECT t1.userid,t1.username,t1.tucode,t1.groupids, t1.corpid, t1.type,
tc.taid, tc.tastartdate, tc.taenddate ,tc.tacode,tc.taname,tc.allowsignup,tc.signupenddate,tc.signupstartdate
FROM
(SELECT tu.tuid userid,tu.tuname username,tu.tucode,tu.groupids, tu.corpid, tu.workdate,tau.taid,tau.type
 FROM trainingactuser tau,Tuser tu
 WHERE tau.entityid=tu.tuid AND tau.type=1 AND tau.status=1
 UNION
 SELECT tu.tuid userid,tu.tuname username,tu.tucode,tu.groupids, tu.corpid, tu.workdate,tau.taid,tau.type
 FROM trainingactuser tau,Tuser tu
 WHERE tau.entityid = tu.deptid  AND tau.type = 2
 UNION
 SELECT tu.tuid userid,tu.tuname username,tu.tucode,tu.groupids, tu.corpid, tu.workdate,tau.taid,tau.type
 FROM trainingactuser tau,Tuser tu, tuserstation ts
 WHERE ts.userid=tu.tuid AND tau.entityID = ts.userid and tau.TYPE=3 ) t1,
(SELECT taid, tastartdate ,taenddate,tacode,taname,signupenddate, signupstartdate,allowsignup
 FROM trainingactivity ta WHERE ta.state=1 /*AND NOT EXISTS (SELECT taid FROM tastudycontent tasc WHERE ta.taid = tasc.taid)*/) tc
WHERE  t1.taid = tc.taid
/*AND to_date(t1.workdate,'yyyy-mm-dd') <= to_date(tc.signupenddate,'yyyy-mm-dd')*/
/

