create PROCEDURE             deleteTrainingUserByGroup
(taid number,creatid number) as

/******************************************************************************
   NAME:       CentralizedPlacementFunds
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2007-6-17   zhaoyuyang       1. Created this procedure.

   NOTES: ？？？？？？？？μ？？？？？？？？？？(TrainingActUserFinally)？？？？？？？？？？？？？？？？？

******************************************************************************/

tempUserid number :=0; --？？？trigger？？？？？TrainingActUser？？？？μ？？？
tempUserid1 number :=0; --？？？？？trigger？？？？？TrainingActUser？？？？μ？？？

--？α？1？？？？？？trigger？？？？？TrainingActUser？？？？μ？？？
  	cursor rs_cursor1 is
           select tu.tuid,tau.entityid,tau.taid,tau.creatorid from TrainingActUser tau,tuser tu
           where tau.entityid = tu.deptid and tau.type = 2 and tau.isautomatism = 1 and tau.taid = taid;
    rs1 rs_cursor1%rowtype;

--？α？2？？？？？？？？trigger？？？？？TrainingActUser？？？？μ？？？,？？？？？？？？？？？？？？
    cursor rs_cursor2 is
           select tu.tuid,tau.entityid,tau.taid,tau.creatorid from TrainingActUser tau,tuser tu
           where tau.entityid = tu.deptid and tau.type = 2 and tau.isautomatism = 0 and tau.taid = taid;
    rs2 rs_cursor2%rowtype;

BEGIN

     for rs1 in rs_cursor1
         loop
             select tauf.userid into tempUserid from TrainingActUserFinally tauf
             where tauf.taid = rs1.taid and tauf.userid = rs1.tuid;

             if (tempUserid = 0) then

                insert into TrainingActUserFinally(taid,userid,entitytypeids,isautomatism,creatorid,createtime)
                values(taid,rs1.tuid,'B_'||rs1.entityid,1,creatid,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

             else

                 update TrainingActUserFinally tauf set entitytypeids = entitytypeids || ('B_'||rs1.entityid)
                 where tauf.taid = rs1.taid and tauf.userid = rs1.tuid;

             end if;
             /

