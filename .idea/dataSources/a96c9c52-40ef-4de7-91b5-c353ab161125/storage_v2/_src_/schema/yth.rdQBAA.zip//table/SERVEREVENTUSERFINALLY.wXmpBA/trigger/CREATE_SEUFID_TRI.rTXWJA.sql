create trigger CREATE_SEUFID_TRI
    before insert
    on SERVEREVENTUSERFINALLY
    for each row
declare
tmpvar number ;
begin
 select DISTRIBUTEACCOUNT_SEQ.nextval into tmpvar from dual;
    :new.seufid := tmpvar;
end create_seufid_tri;
/

