create PROCEDURE             addGroupAccountsByAlone
(groupid number,balance number,totalamount number,dayear number,creatorid number,createtime varchar2) as

/******************************************************************************
   NAME:       addAllAssignmentAccounts
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2007-6-17    zhaoyuyang                1. Created this procedure.

   NOTES: ？？？？？？？？？？？？？？？？？？？？？？

******************************************************************************/
  	cursor rs_cursor1 is
           SELECT tgid FROM tgroup CONNECT BY PRIOR tgid = parentid START WITH tgid = groupid;
    rs1 rs_cursor1%rowtype;

BEGIN

   	for rs1 in rs_cursor1
       loop
       INSERT INTO Distributeaccount
       (daid,entitytype,entityid,totalamount,balance,creatorid,createtime,dayear)
       values(1,2,rs1.tgid,totalamount,balance,creatorid,createtime,dayear);
	   end loop;
    /

