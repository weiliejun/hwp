create PROCEDURE AddFundsToOneUser
(varMomeny number,varCreatorid number,varSelectTgid number,
varNeedFundTgid number,varDayear number,varCreatetime varchar,varDaid number,varUserid number) as

/******************************************************************************
   NAME:       NewUnifiedFundsAssigned
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2008-8-18   zhaoyuyang       1. Created this procedure.

   NOTES: 给一个员工分配经费

   入口参数说明：

   varMomeny 单个实体分配的金额；varUserCount 需要分配金额机构下的总人数；varCreatorid 操作员；

   varSelectTgid 经费来源机构; varNeedFundTgid 需要得到经费的机构；varDayear 当前的有效年度; varCreatetime 操作时间

   varDaid 分配帐户的id; varUserid 得到分配金额的人员

******************************************************************************/

varBanlance number :=0;
--游标1 查询分配帐户表中的机构帐户
cursor rs_cursor1 is
        select tempGroup.tgid
           from (select tg.tgid,tg.parentid
                   from tgroup tg
                  start with tg.tgid = varNeedFundTgid
                 connect by prior tg.parentid = tg.tgid) tempGroup
         connect by prior tgid = parentid
          start with tgid = varSelectTgid;
rs1 rs_cursor1%rowtype;

BEGIN
         select balance into varBanlance from  Distributeaccount where accountisdelete = 0 and entitytype = 1 and daid= varDaid and dayear = varDayear;

             if (varMomeny + varBanlance) >= 0 then


                 -- 选择经费出处后，从指定的经费划拨节点到当前节点都应做相关的经费操作。对于经费划拨节点，需要减去费用；对于当前节点，需要增加费用；对于经费划拨节点和当前节点之间的各级节点，需要增加费用并同时减去等值的费用，这些操作都应记录流水帐。这样做的目的是保持各个机构节点的经费进出总帐合理

                 if varNeedFundTgid = 9002 then

                         update distributeaccount set balance = balance -  varMomeny where entitytype = 2 and entityid = varNeedFundTgid and dayear = varDayear;

                         INSERT INTO Distributeaccountlist
                         (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                         values
                         (1,2,varNeedFundTgid,2,varMomeny,varDayear,varCreatetime,'分配帐户--机构--出帐经费（存储过程）',varCreatorid,varCreatetime);

                 else
                        if varSelectTgid != varNeedFundTgid then
                           for rs1 in rs_cursor1
                               loop

                                   if (rs1.tgid != 9002 and rs1.tgid != varSelectTgid) then

                                     update distributeaccount set totalamount = totalamount + varMomeny
                                     where entitytype = 2 and entityid = rs1.tgid and dayear = varDayear;

                                     INSERT INTO Distributeaccountlist
                                     (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                                     values
                                     (1,2,rs1.tgid,1,varMomeny,varDayear,varCreatetime,'分配帐户--机构--入帐经费（存储过程）',varCreatorid,varCreatetime);
                                   end if;
                                   -- 当为总机构建立流水帐时只有出帐没有入账
                                   if (rs1.tgid = 9002 or rs1.tgid = varSelectTgid) then
                                         update distributeaccount set balance = balance -  varMomeny
                                         where entitytype = 2 and entityid = rs1.tgid and dayear = varDayear;
                                   end if;

                                   INSERT INTO Distributeaccountlist
                                   (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                                   values
                                   (1,2,rs1.tgid,2,varMomeny,varDayear,varCreatetime,'分配帐户--机构--出帐经费（存储过程）',varCreatorid,varCreatetime);

                      	     end loop;

                         else

                                   update distributeaccount set balance = balance - varMomeny where entitytype = 2 and entityid = varNeedFundTgid and dayear = varDayear;

                                   INSERT INTO Distributeaccountlist
                                   (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                                   values
                                   (1,2,varNeedFundTgid,2,varMomeny,varDayear,varCreatetime,'分配帐户--机构--出帐经费（存储过程）',varCreatorid,varCreatetime);
                         end if;
                 end if;

                   update Distributeaccount set totalamount = totalamount + varMomeny,balance = balance + varMomeny
                   where accountisdelete = 0 and entitytype = 1 and daid= varDaid and dayear = varDayear;
                   INSERT INTO Distributeaccountlist(dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                   values (1,1,varUserid,1,varMomeny,varDayear,varCreatetime,'分配帐户--人员--入帐经费（存储过程）',varCreatorid,varCreatetime);

          end if;
  --commit;

   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('error='||sqlcode||',sqlerrm='||sqlerrm);
		   rollback;
END AddFundsToOneUser;
/

