create view VALLGROUPS as
(select tgb.tgid,tgb.tgcode,tgb.tgname,tgb.parentid from tgroupbak tgb)
union all
(select  tg.tgid,tg.tgcode,tg.tgname,tg.parentid from tgroup tg)


/

