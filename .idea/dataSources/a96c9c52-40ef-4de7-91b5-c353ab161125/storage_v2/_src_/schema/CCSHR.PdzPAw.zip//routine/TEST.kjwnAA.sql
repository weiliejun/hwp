create PROCEDURE             test
(entityid number,type number,includechildren number,taid number,creatorid number,createtime varchar2,isautomatism number) as


   cursor rs_cursor is
      select tgid from tgroup where tgid != 9002 connect by prior tgid=parentid start with tgid = 9002;
    rs rs_cursor%rowtype;

begin

    if(type=2 and isautomatism = 0 and includechildren = 1) then
      for rs in rs_cursor
      loop
         delete from TrainingActSignUp tasu where tasu.entityid = rs.tgid and tasu.taid = 18202
         and tasu.entitytype = 2;
      end loop;
	  end if;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('error='||sqlcode||',sqlerrm='||sqlerrm);
		   rollback;
END test;


/

