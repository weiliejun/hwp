create PROCEDURE             CentralizedPlacementFunds
(momeny number,userCount number,administratorUserID number,administratorsGroupID number,currentGroupID number,isChildDept number,dayear number) as

/******************************************************************************
   NAME:       CentralizedPlacementFunds
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2007-6-17   zhaoyuyang       1. Created this procedure.

   NOTES: 机构分配经费

******************************************************************************/
userNumberTemp number :=0; --临时存放某个机构及其子机构的总人数


--游标4 查询分配帐户表中的机构帐户
    cursor rs_cursor4 is
           select da.entityid as tgid from distributeaccount da where da.entitytype = 2 and da.dayear = dayear and da.accountisdelete = 0;
    rs4 rs_cursor4%rowtype;

--游标6查询分配帐户表中的人员帐户 不包含子机构的人
  	cursor rs_cursor6 is
           select da.entityid as tuid from distributeaccount da ,tuser tu
           where da.entitytype = 1 and da.dayear = dayear and tu.tuid = da.entityid and tu.deptid = currentGroupID;
    rs6 rs_cursor6%rowtype;

--游标7查询分配帐户表中的人员帐户 包含子机构的人
  	cursor rs_cursor7 is
         select tu.tuid
         from distributeaccount da,(SELECT tgid FROM tgroup CONNECT BY PRIOR tgid = parentid START WITH tgid = currentGroupID) tempgroup, tuser tu
         where da.entitytype = 1 and da.entityid = tu.tuid and tempgroup.tgid =tu.deptid and da.dayear = dayear;
    rs7 rs_cursor7%rowtype;

BEGIN


     update distributeaccount set balance = balance - (userCount*momeny)
     where entitytype = 2 and entityid = administratorsGroupID and dayear = dayear;

     INSERT INTO Distributeaccountlist
     (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
     values
     (1,2,administratorsGroupID,1,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'分配帐户--机构--入帐经费',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

     INSERT INTO Distributeaccountlist
     (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
     values
     (1,2,administratorsGroupID,2,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'分配帐户--机构--出帐经费',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

    if isChildDept = 0 then
        --给人分配经费
       	for rs6 in rs_cursor6
           loop
                 update distributeaccount set totalamount = totalamount+momeny,balance = balance + momeny
                 where entitytype = 1 and entityid = rs6.tuid and dayear = dayear;

                 INSERT INTO Distributeaccountlist
                        (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                 values
                       (1,1,rs6.tuid,1,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'分配帐户--学员--入账经费（存储过程）',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

    	     end loop;


         --此句不包含子机构
         if currentGroupID != administratorsGroupID then
             update distributeaccount set totalamount = totalamount+(userCount*momeny)
             where entitytype = 2 and entityid = currentGroupID and dayear = dayear;

             INSERT INTO Distributeaccountlist
             (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
             values
             (1,2,currentGroupID,1,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'分配帐户--机构--入账经费（存储过程）',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

             INSERT INTO Distributeaccountlist
             (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
             values
             (1,2,currentGroupID,2,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'分配帐户--机构--出账经费（存储过程）',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
         end if;
    else

        --给人员分配经费 包含子机构
        for rs7 in rs_cursor7
           loop

                 --每个机构节点下面的人分配经费
                 update distributeaccount set totalamount = totalamount+momeny,balance = balance + momeny
                 where entitytype = 1 and entityid = rs7.tuid and dayear = dayear;

                 INSERT INTO Distributeaccountlist
                        (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                 values
                       (1,1,rs7.tuid,1,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'分配帐户--学员--入账经费（存储过程）',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

    	     end loop;

        --给机构分配经费 包含子机构
        for rs4 in rs_cursor4

           loop

                 if rs4.tgid != administratorsGroupID then

                    /**
                     --每个机构节点的分配经费就是它下面的总人数乘以分配经额
                     **/
                    select count(tu.tuid) into userNumberTemp
                    from distributeaccount da,(SELECT tgid FROM tgroup CONNECT BY PRIOR tgid = parentid START WITH tgid = rs4.tgid) tempgroup, tuser tu
                    where da.entitytype = 1 and da.entityid = tu.tuid and tempgroup.tgid =tu.deptid and da.dayear = dayear;

                     update distributeaccount set totalamount = totalamount+(momeny*userNumberTemp)
                     where entitytype = 2 and entityid = rs4.tgid and dayear = dayear;

                     INSERT INTO Distributeaccountlist
                     (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                     values
                     (1,2,rs4.tgid,1,momeny*userNumberTemp,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'分配帐户--机构--入账经费（存储过程）',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

                     INSERT INTO Distributeaccountlist
                     (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                     values
                     (1,2,rs4.tgid,2,momeny*userNumberTemp,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'分配帐户--机构--出账经费（存储过程）',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

                 end if;

         end loop;

   end if;



	commit;

   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('error='||sqlcode||',sqlerrm='||sqlerrm);
		   rollback;
END CentralizedPlacementFunds;


/

