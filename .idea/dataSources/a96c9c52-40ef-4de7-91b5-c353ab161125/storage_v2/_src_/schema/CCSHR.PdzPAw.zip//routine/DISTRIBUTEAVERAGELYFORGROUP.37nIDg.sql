create PROCEDURE             DistributeAveragelyForGroup
(momeny number,userCount number,administratorUserID number,administratorsGroupID number,currentGroupID number,isChildDept number,dayear number) as

/******************************************************************************
   NAME:       CentralizedPlacementFunds
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2007-6-17   zhaoyuyang       1. Created this procedure.

   NOTES: 各机构平均分配经费

******************************************************************************/
groupNum number :=0; --根据机构id得到所有的子机构数

--游标3 查询包含子机构的机构id
    cursor rs_cursor1 is
           SELECT tgid FROM tgroup where tgid != currentGroupID CONNECT BY PRIOR tgid = parentid START WITH tgid = currentGroupID;
    rs1 rs_cursor1%rowtype;

BEGIN

     SELECT count(tgid) into groupNum FROM tgroup where tgid != currentGroupID CONNECT BY PRIOR tgid = parentid START WITH tgid = currentGroupID;
     update distributeaccount set balance = balance - (groupNum*momeny)
     where entitytype = 2 and entityid = administratorsGroupID and dayear = dayear;

     INSERT INTO Distributeaccountlist
     (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
     values
     (1,2,administratorsGroupID,1,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'分配帐户--管理员--入帐经费',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

     INSERT INTO Distributeaccountlist
     (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
     values
     (1,2,administratorsGroupID,2,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'分配帐户--管理员--出帐经费',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

    for rs1 in rs_cursor1
      loop
       update distributeaccount set totalamount = totalamount+momeny,balance = balance + momeny
       where entitytype = 2 and entityid = rs1.tgid and dayear = dayear;

       INSERT INTO Distributeaccountlist
              (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
       values
             (1,2,rs1.tgid,1,momeny,dayear,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'分配帐户入账经费（存储过程）',administratorUserID,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

      end loop;

   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('error='||sqlcode||',sqlerrm='||sqlerrm);
		   rollback;
END DistributeAveragelyForGroup;


/

