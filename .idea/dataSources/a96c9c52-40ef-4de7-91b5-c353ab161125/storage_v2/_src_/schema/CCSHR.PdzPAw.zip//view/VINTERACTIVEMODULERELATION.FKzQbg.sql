create view VINTERACTIVEMODULERELATION as
SELECT ta.taid,ta.tacode,t1.imrid,t1.imrcode,t1.imrname,t1.entitytype,t1.state,t1.entityid,ta.taname
FROM
(
    SELECT ta.taid,'forumname' as imrname,'forumname' as imrcode,imr.entitytype,imr.state,imr.entityid,imr.imrid
    FROM trainingactivity ta,InteractiveModuleRelation imr
    WHERE ta.taid = imr.taid and imr.entitytype = 1
    UNION all
    SELECT ta.taid,see.seename as imrname,see.seecode as imrcode,imr.entitytype,imr.state,imr.entityid,imr.imrid
    FROM trainingactivity ta,InteractiveModuleRelation imr,ServerEventEntity see
    WHERE ta.taid = imr.taid and imr.entitytype = 2 and imr.entityid = see.seeid
    UNION all
    SELECT ta.taid,rrp.title as imrname,rrp.rrpcode as imrcode,imr.entitytype,imr.state,imr.entityid,imr.imrid
    FROM trainingactivity ta,InteractiveModuleRelation imr,RequireResearchPaper rrp
    WHERE ta.taid = imr.taid and imr.entitytype = 3 and imr.entityid = rrp.rrpid
    UNION all
    SELECT ta.taid,ta.taname||' Answer Room' as imrname,ta.taname||' Answer Room' as imrcode,imr.entitytype,imr.state,imr.entityid,imr.imrid
    FROM trainingactivity ta,InteractiveModuleRelation imr
    WHERE ta.taid = imr.taid and imr.entitytype = 5
) t1,trainingactivity ta where ta.taid = t1.taid
/

