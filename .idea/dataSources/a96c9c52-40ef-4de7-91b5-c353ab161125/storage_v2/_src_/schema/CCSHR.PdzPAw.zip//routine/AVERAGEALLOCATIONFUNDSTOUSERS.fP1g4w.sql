create PROCEDURE AverageAllocationFundsToUsers
(varMomeny number,varUserCount number,varCreatorid number,varSelectTgid number,varNeedFundTgid number,varDayear number,varCreatetime varchar) as

/******************************************************************************
   NAME:       NewUnifiedFundsAssigned
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2008-8-18   zhaoyuyang       1. Created this procedure.

   NOTES: 给某个机构下的人员平均分配经费（不包含子机构）

   入口参数说明：

   varMomeny 单个实体分配的金额；varUserCount 需要分配金额机构下的总人数；varCreatorid 操作员；

   varSelectTgid 经费来源机构; varNeedFundTgid 人员所属机构；varDayear 当前的有效年度; varCreatetime 操作时间

******************************************************************************/

varBanlance number :=0;
varUserCountTempOne number := varUserCount;
varUserCountTempTwo number := 1;

--游标1 根据varNeedFundTgid查询分配帐户表中需要分配经费的人员（不包含子机构）帐户
cursor rs_cursor1 is
     select tu.tuid
       from distributeaccount da, tgroup tg, tuser tu
      where da.entitytype = 1
        and da.entityid = tu.tuid
        and tg.tgid = tu.deptid
        and da.dayear = varDayear
        and da.accountisdelete = 0
        and tg.tgid = varNeedFundTgid;
rs1 rs_cursor1%rowtype;


--游标3 查询分配帐户表中的机构帐户
cursor rs_cursor3 is
        select tempGroup.tgid
           from (select tg.tgid,tg.parentid
                   from tgroup tg
                  start with tg.tgid = varNeedFundTgid
                 connect by prior tg.parentid = tg.tgid) tempGroup
         connect by prior tgid = parentid
          start with tgid = varSelectTgid;
rs3 rs_cursor3%rowtype;

BEGIN

         for rs1 in rs_cursor1
           loop
                 select balance into varBanlance from Distributeaccount
                 where accountisdelete = 0 and entitytype = 1 and entityid = rs1.tuid and dayear = varDayear;

                 if (varBanlance+varMomeny) < 0 then

                    varUserCountTempTwo := (varUserCountTempOne-1);
                    varUserCountTempOne := (varUserCountTempOne-1);

                 end if;

    	     end loop;

           if varUserCountTempOne > 0 then
              -- 选择经费出处后，从指定的经费划拨节点到当前节点都应做相关的经费操作。对于经费划拨节点，需要减去费用；对于当前节点，需要增加费用；对于经费划拨节点和当前节点之间的各级节点，需要增加费用并同时减去等值的费用，这些操作都应记录流水帐。这样做的目的是保持各个机构节点的经费进出总帐合理
              if varNeedFundTgid = 9002 then

                     update distributeaccount set balance = balance - (varUserCountTempOne*varMomeny) where entitytype = 2 and entityid = varNeedFundTgid and dayear = varDayear;

                     INSERT INTO Distributeaccountlist
                     (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                     values
                     (1,2,varNeedFundTgid,2,(varUserCountTempOne*varMomeny),varDayear,varCreatetime,'分配帐户--机构--出帐经费（存储过程）',varCreatorid,varCreatetime);

             else


                     if varSelectTgid != varNeedFundTgid then
                         for rs3 in rs_cursor3
                             loop

                                 if (rs3.tgid != 9002 and rs3.tgid != varSelectTgid) then

                                   update distributeaccount set totalamount = totalamount + (varUserCountTempOne*varMomeny)
                                   where entitytype = 2 and entityid = rs3.tgid and dayear = varDayear;

                                   INSERT INTO Distributeaccountlist
                                   (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                                   values
                                   (1,2,rs3.tgid,1,varUserCountTempOne*varMomeny,varDayear,varCreatetime,'分配帐户--机构--入帐经费（存储过程）',varCreatorid,varCreatetime);

                                 end if;
                                 -- 当为总机构建立流水帐时只有出帐没有入账
                                 if (rs3.tgid = 9002 or rs3.tgid = varSelectTgid) then
                                       update distributeaccount set balance = balance - (varUserCountTempOne*varMomeny)
                                       where entitytype = 2 and entityid = rs3.tgid and dayear = varDayear;
                                 end if;


                                 INSERT INTO Distributeaccountlist
                                 (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                                 values
                                 (1,2,rs3.tgid,2,varUserCountTempOne*varMomeny,varDayear,varCreatetime,'分配帐户--机构--出帐经费（存储过程）',varCreatorid,varCreatetime);

                    	     end loop;

                     else

                               update distributeaccount set balance = balance - (varUserCountTempOne*varMomeny) where entitytype = 2 and entityid = varNeedFundTgid and dayear = varDayear;


                               INSERT INTO Distributeaccountlist
                               (dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                               values
                               (1,2,varNeedFundTgid,2,(varUserCountTempOne*varMomeny),varDayear,varCreatetime,'分配帐户--机构--出帐经费（存储过程）',varCreatorid,varCreatetime);
                     end if;
               end if;
            --给人员分配经费
            for rs1 in rs_cursor1
               loop

                     select balance into varBanlance from Distributeaccount
                     where accountisdelete = 0 and entitytype = 1 and entityid = rs1.tuid and dayear = varDayear;

                     if (varBanlance+varMomeny) >= 0 then

                       update Distributeaccount set totalamount = totalamount + varMomeny,balance = balance + varMomeny
                       where accountisdelete = 0 and entitytype = 1 and entityid = rs1.tuid and dayear = varDayear;
                       INSERT INTO Distributeaccountlist(dalid,entitytype,entityid,feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                       values (1,1,rs1.tuid,1,varMomeny,varDayear,varCreatetime,'分配帐户--人员--入帐经费（存储过程）',varCreatorid,varCreatetime);

                     end if;
        	     end loop;


           end if;


	--commit;

   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('error='||sqlcode||',sqlerrm='||sqlerrm);
		   rollback;
END AverageAllocationFundsToUsers;
/

