create trigger RESOURCEDISTRIBUTION_TRI
    before insert
    on RESOURCEDISTRIBUTION
    for each row
    when (new.isAutomatism = 0 and new.IncludeChildren = 1)
declare
   newTgidVar number := :new.tgid;
   tempTgidVar number := 0;        --存储机构id的变量。用来判断是否是已经存在的机构
   cursor rs_cursor is
      select tgid from tgroup where tgid != newTgidVar connect by prior tgid = parentid start with tgid = newTgidVar;
    rs rs_cursor%rowtype;
begin
    for rs in rs_cursor
    loop
        select count(tgid) into tempTgidVar from ResourceDistribution rd where rd.tgid = rs.tgid and rd.rbid = :new.rbid and parenttgid = newTgidVar;
        if(tempTgidVar = 0) then
             insert into ResourceDistribution (rbid, rtid, tgid, isautomatism, creatorid, createtime, parenttgid)
             values (:new.rbid, :new.rtid, rs.tgid, 1, :new.creatorid, :new.createtime, newTgidVar);
        end if;
    end loop;


  EXCEPTION
    WHEN NO_DATA_FOUND THEN
    NULL;
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('error='||sqlcode||',sqlerrm='||sqlerrm);
   rollback;
end;


/

