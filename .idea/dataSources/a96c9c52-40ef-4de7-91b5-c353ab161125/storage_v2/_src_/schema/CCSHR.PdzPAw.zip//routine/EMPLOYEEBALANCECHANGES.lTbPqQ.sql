create PROCEDURE             EmployeeBalanceChanges
(stopYear number,startYear number,creatorid number,createtime varchar2,operatetime varchar2,flag number) as

/******************************************************************************
   NAME:       EmployeeBalanceChanges
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2007-6-19   zhaoyuyang                 1. Created this procedure.

   NOTES:员工分配经费余额转移
******************************************************************************/

  	cursor rs_cursor1 is
    select daid,entitytype,entityid,totalamount,balance,dayear from distributeaccount where dayear = stopYear;
    rs1 rs_cursor1%rowtype;

    cursor rs_cursor2 is
       select daid,entitytype,entityid,totalamount,balance,dayear from distributeaccount where dayear = startYear;
    rs2 rs_cursor2%rowtype;

BEGIN

     for rs1 in rs_cursor1
         loop
             for rs2 in rs_cursor2
                 loop
                     if (rs1.entitytype = rs2.entitytype and rs1.entityid = rs2.entityid) then
                        if(rs1.entityid != 9002 and rs2.entityid != 9002)  then

                          update distributeaccount
                          set totalamount = totalamount + rs1.balance,balance = balance + rs1.balance
                          where dayear = startYear and entitytype = rs2.entitytype and entityid=rs2.entityid;

                          INSERT INTO Distributeaccountlist (dalid,daid,entitytype,entityid,
                          feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                          values(1,rs1.daid,rs1.entitytype,rs1.entityid,2,rs1.balance,stopYear,operatetime,'分配帐户流水出账经费',creatorid,createtime);

                          INSERT INTO Distributeaccountlist (dalid,daid,entitytype,entityid,
                          feetype,money,dalyear,operatetime,operatecontent,creatorid,createtime)
                          values(1,rs2.daid,rs2.entitytype,rs2.entityid,1,rs1.balance,startYear,operatetime,'分配帐户流水入账经费',creatorid,createtime);

                          end if;
                     end if;
                 end loop;
         end loop;

   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('error='||sqlcode||',sqlerrm='||sqlerrm);
       rollback;

END EmployeeBalanceChanges;


/

