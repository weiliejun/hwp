create PROCEDURE saveClassroomUserFromTrainUser
(taidvar number,seeid number,othermodeltype number,creatorid number,createtime varchar2) as

/******************************************************************************
   NAME:       saveClassroomUserFromTrainUser
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2008-1-17   zhaoyuyang       1. Created this procedure.

   NOTES: 保存培训活动互动组件增加的同步课堂的参与人员

******************************************************************************/


--游标1 查询培训活动最终人员表

    cursor rs_cursor1 is
     select tauf.taufid,tauf.taid,tauf.userid from TrainingActUserFinally tauf where tauf.taid = taidvar and tauf.status = 1;
    rs1 rs_cursor1%rowtype;


BEGIN

        for rs1 in rs_cursor1
           loop

                     INSERT INTO Servereventuserfinally
                     (seeid,tuid,entitytypeids,othermodelid,othermodeltype,creatorid,createtime)
                     values
                     (seeid,rs1.userid,'@A_'||rs1.userid,taidvar,othermodeltype,creatorid,createtime);

         end loop;

	--commit;

   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('error='||sqlcode||',sqlerrm='||sqlerrm);
		   rollback;
END saveClassroomUserFromTrainUser;
/

