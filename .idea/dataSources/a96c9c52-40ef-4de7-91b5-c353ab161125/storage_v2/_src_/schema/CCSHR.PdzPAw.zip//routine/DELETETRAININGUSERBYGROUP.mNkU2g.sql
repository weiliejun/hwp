create PROCEDURE deleteTrainingUserByGroup
(taid number,creatid number) as

/******************************************************************************
   NAME:       CentralizedPlacementFunds
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2007-6-17   zhaoyuyang       1. Created this procedure.

   NOTES: 向培训活动参加最终人员表(TrainingActUserFinally)中增加由机构指定的人员

******************************************************************************/

tempUserid number :=0; --通过trigger插入表TrainingActUser的机构下的人
tempUserid1 number :=0; --不通过trigger插入表TrainingActUser的机构下的人

--游标1查询通过trigger插入表TrainingActUser的机构下的人
  	cursor rs_cursor1 is
           select tu.tuid,tau.entityid,tau.taid,tau.creatorid from TrainingActUser tau,tuser tu
           where tau.entityid = tu.deptid and tau.type = 2 and tau.isautomatism = 1 and tau.taid = taid;
    rs1 rs_cursor1%rowtype;

--游标2查询不通过trigger插入表TrainingActUser的机构下的人,既不包含子机构的人员。
    cursor rs_cursor2 is
           select tu.tuid,tau.entityid,tau.taid,tau.creatorid from TrainingActUser tau,tuser tu
           where tau.entityid = tu.deptid and tau.type = 2 and tau.isautomatism = 0 and tau.taid = taid;
    rs2 rs_cursor2%rowtype;

BEGIN

     for rs1 in rs_cursor1
         loop
             select tauf.userid into tempUserid from TrainingActUserFinally tauf
             where tauf.taid = rs1.taid and tauf.userid = rs1.tuid;

             if (tempUserid = 0) then

                insert into TrainingActUserFinally(taid,userid,entitytypeids,isautomatism,creatorid,createtime)
                values(taid,rs1.tuid,'B_'||rs1.entityid,1,creatid,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

             else

                 update TrainingActUserFinally tauf set entitytypeids = entitytypeids || ('B_'||rs1.entityid)
                 where tauf.taid = rs1.taid and tauf.userid = rs1.tuid;

             end if;
         end loop;


     for rs2 in rs_cursor2
         loop
             select tauf.userid into tempUserid from TrainingActUserFinally tauf
             where tauf.taid = rs2.taid and tauf.userid = rs2.tuid;

             if (tempUserid1 = 0) then

                insert into TrainingActUserFinally(taid,userid,entitytypeids,isautomatism,creatorid,createtime)
                values(taid,rs2.tuid,'B_'||rs2.entityid,1,creatid,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

             else

                 update TrainingActUserFinally tauf set entitytypeids = entitytypeids || ('B_'||rs2.entityid)
                 where tauf.taid = rs2.taid and tauf.userid = rs2.tuid;

             end if;
         end loop;

	commit;

   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('error='||sqlcode||',sqlerrm='||sqlerrm);
		   rollback;
END deleteTrainingUserByGroup;


/

