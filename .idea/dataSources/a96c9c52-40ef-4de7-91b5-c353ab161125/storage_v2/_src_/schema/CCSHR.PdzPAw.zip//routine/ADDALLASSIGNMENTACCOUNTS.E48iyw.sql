create PROCEDURE             addAllAssignmentAccounts
(balance number,totalamount number,dayear number,creatorid number,createtime varchar2) as

/******************************************************************************
   NAME:       addAllAssignmentAccounts
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2007-6-17    zhaoyuyang                1. Created this procedure.

   NOTES: 为所有的机构节点和人员增加分配帐户

******************************************************************************/
  	cursor rs_cursor1 is
    select tgid from tgroup where tgid >= 10000 ORDER BY TGID;
    rs1 rs_cursor1%rowtype;

    cursor rs_cursor2 is
    select tuid from tuser where tuid >= 10000 ORDER BY TUID;
    rs2 rs_cursor2%rowtype;
BEGIN

   	for rs1 in rs_cursor1
       loop
       INSERT INTO Distributeaccount
       (daid,entitytype,entityid,totalamount,balance,creatorid,createtime,dayear)
       values(1,2,rs1.tgid,totalamount,balance,creatorid,createtime,dayear);
	   end loop;
	commit;

   for rs2 in rs_cursor2
       loop
       INSERT INTO Distributeaccount
       (daid,entitytype,entityid,totalamount,balance,creatorid,createtime,dayear)
       values(1,1,rs2.tuid,totalamount,balance,creatorid,createtime,dayear);
	   end loop;
	commit;

   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       rollback;
END addAllAssignmentAccounts;


/

