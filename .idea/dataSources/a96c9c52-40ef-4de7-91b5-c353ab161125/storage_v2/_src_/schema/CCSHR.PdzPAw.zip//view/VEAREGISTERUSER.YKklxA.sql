create view VEAREGISTERUSER as
SELECT earu.entityid tuid,tu.tuname tuname, tu.tucode, earu.eaid
FROM EXAMARRANGE ea,EAREGISTERUSER earu ,TUSER tu 
WHERE earu.entityID=tu.tuid
AND ea.eaid=earu.eaid
AND earu.TYPE=1

UNION
SELECT distinct tu.tuid tuid,tu.tuname tuname, tu.tucode, earu.eaid
FROM EXAMARRANGE ea,EAREGISTERUSER earu ,TUSER tu ,TGROUP tg
WHERE earu.entityid = tg.tgid
AND earu.eaid=ea.eaid
AND tu.groupids  like ',,%'||tg.tgid||'%,,'
AND earu.TYPE=2

UNION
SELECT distinct tu.tuid tuid,tu.tuname tuname, tu.tucode, earu.eaid
FROM EXAMARRANGE ea,EAREGISTERUSER earu ,TUSER tu ,STATION st,tuserstation tust
WHERE earu.entityid = st.stid
AND earu.eaid=ea.eaid
AND tust.stationid=st.stid
AND earu.TYPE=3
/

