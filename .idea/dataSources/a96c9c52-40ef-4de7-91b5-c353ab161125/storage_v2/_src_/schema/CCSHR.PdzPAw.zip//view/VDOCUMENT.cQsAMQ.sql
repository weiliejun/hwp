create view VDOCUMENT as
select doc.docid, doc.code, doc.name, doc.maincontent, doc.note,
doc.docmakemethod, doc.rtids,doc.studydays,
rb.rbid, rb.kcid, rb.rtid, rb.tgid, rb.title,
rb.identifier, rb.description, rb.keyword,
rb.creator, rb.toll, rb.publisher, rb.publishdate,
rb.language, rb.audience, rb.isopen, rb.issuestatus,
rb.usetimes, rb.scantimes, rb.creatorid, rb.createtime, 0 shareresource, rb.tgid usetgid
from document doc, resourcebasic rb where doc.docid=rb.rbid
union
select doc.docid, doc.code, doc.name, doc.maincontent, doc.note,
doc.docmakemethod, doc.rtids,doc.studydays,
rb.rbid, rb.kcid, rb.rtid, rb.tgid, rb.title,
rb.identifier, rb.description, rb.keyword,
rb.creator, rb.toll, rb.publisher, rb.publishdate,
rb.language, rb.audience, rb.isopen, rb.issuestatus,
rb.usetimes, rb.scantimes, rb.creatorid, rb.createtime, 1 shareresource, rd.tgid usetgid
from document doc, resourcebasic rb, resourcedistribution rd
where doc.docid = rb.rbid and rb.rbid = rd.rbid and rd.rtid = 9002 and rb.issuestatus = 1


/

