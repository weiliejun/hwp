create trigger TR_EXAMMARKUSER_TYPE
    after insert
    on EXAMARRANGEUSER
    for each row
declare
   entityidVar number := :new.entityid;
   typeVar number := :new.type;
   eaidVar number := :new.eaid;
   isautoinsertVar number := :new.isautoinsert;
   markuserVar number := -1;
   cursor rs_cursor_tg is
          select deptid,tuid from tuser where deptid = entityidVar;
   rs_tg rs_cursor_tg%rowtype;
   cursor rs_cursor_st is
          select tu.deptid,tu.tuid from tuser tu,tuserstation ts 
          where tu.tuid = ts.userid and ts.stationid = entityidVar;
   rs_st rs_cursor_st%rowtype;
 
begin               
   if(typeVar=1) then --插入人员
         select nvl(sum(eamk.tuid),-1) into markuserVar from eamark eamk where eamk.eaid = eaidVar and  eamk.tuid = entityidVar;
         if  (markuserVar = -1) then
             insert into eamark (eaid,tuid,entitytypeids,tgid,issignup,isautomatism)
             values(eaidVar,entityidVar,'@A_'||entityidVar,(select deptid from tuser where tuid=entityidVar),0,1);
         else        
             update eamark  set entitytypeids = entitytypeids || ('@A_'||entityidVar) 
             where eaid = eaidVar and tuid = entityidVar;
         end if;
   
   elsif(typeVar=2) then --插入机构的人员
          for rs_tg in rs_cursor_tg
          loop
             select nvl(sum(eamk.tuid),-1) into markuserVar from eamark eamk where eamk.eaid = eaidVar and  eamk.tuid = rs_tg.tuid;
             if (isautoinsertVar = 0) then --程序插入
                if  (markuserVar = -1) then
                   insert into eamark (eaid,tuid,entitytypeids,tgid,issignup,isautomatism)
                   values(eaidVar,rs_tg.tuid,'@B_'||entityidVar,entityidVar,0,1);
                else        
                   update eamark  set entitytypeids = entitytypeids || ('@B_'||entityidVar) 
                   where eaid = eaidVar and tuid = rs_tg.tuid;
                end if;
             else 
                if  (markuserVar = -1) then --后台自动插入
                   insert into eamark (eaid,tuid,entitytypeids,tgid,issignup,isautomatism)
                   values(eaidVar,rs_tg.tuid,'@B_'||:new.id,entityidVar,0,1);
                else        
                   update eamark  set entitytypeids = entitytypeids || ('@B_'||:new.id) 
                   where eaid = eaidVar and tuid = rs_tg.tuid;
                end if;  
             end if;     
          end loop;
          
   elsif(typeVar=3) then --插入岗位人员
          for rs_st in rs_cursor_st
          loop
             select nvl(sum(eamk.tuid),-1) into markuserVar from eamark eamk where eamk.eaid = eaidVar and eamk.tuid = rs_st.tuid;
             if  (markuserVar = -1) then
                 insert into eamark (eaid,tuid,entitytypeids,tgid,issignup,isautomatism)
                 values(eaidVar,rs_st.tuid,'@C_'||entityidVar,rs_st.deptid,0,1);
             else        
                 update eamark  set entitytypeids = entitytypeids || ('@C_'||entityidVar) 
                 where eaid = eaidVar and tuid = rs_st.tuid;
             end if;
          end loop;
   end if;      
exception 
   WHEN NO_DATA_FOUND THEN
     RAISE_APPLICATION_ERROR(-20001,'Some errors(NO_DATA_FOUND) occured in the triger of TR_EXAMMARKUSER_TYPE!');
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20002,'Some errors(OTHERS) occured in the triger of TR_EXAMMARKUSER_TYPE!');
end TR_EXAMMARKUSER_TYPE;
/

