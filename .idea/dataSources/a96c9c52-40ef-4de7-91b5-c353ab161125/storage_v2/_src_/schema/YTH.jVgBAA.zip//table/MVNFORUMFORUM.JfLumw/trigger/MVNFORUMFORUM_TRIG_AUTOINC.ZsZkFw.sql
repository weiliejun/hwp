create trigger MVNFORUMFORUM_TRIG_AUTOINC
    before insert
    on MVNFORUMFORUM
    for each row
begin
  if (:new.ForumID is null) then
    select mvnforumForum_seq.nextval into :new.ForumID from dual;
  end if;
end;
/

