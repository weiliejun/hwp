create view VEVALUATIONUSER as
SELECT eua.entityid tuid,tu.tuname tuname, tu.tucode, ev.eid,123 as type ,ev.evtype,ev.title,ev.begindate,ev.enddate
FROM evaluation ev,evtuserarrange eua ,tuser tu 
WHERE eua.entityid=tu.tuid
AND ev.eid=eua.eid
AND eua.type=1
AND ev.status=1

UNION
SELECT distinct tu.tuid tuid,tu.tuname tuname, tu.tucode, eua.eid,123 as type ,ev.evtype,ev.title,ev.begindate,ev.enddate
FROM evaluation ev,evtuserarrange eua ,tuser tu ,tgroup tg
WHERE eua.entityid = tg.tgid
AND eua.eid=ev.eid
AND ((tu.groupids  like ',,%'||tg.tgid||'%,,' and eua.includechildren=1) or (tu.deptid=tg.tgid and eua.includechildren=0))
AND eua.TYPE=2
AND ev.status=1

UNION
SELECT distinct tu.tuid tuid,tu.tuname tuname, tu.tucode, eua.eid,123 as type ,ev.evtype,ev.title,ev.begindate,ev.enddate
FROM evaluation ev,evtuserarrange eua ,TUSER tu ,STATION st,tuserstation tust
WHERE eua.entityid = st.stid
AND eua.eid=ev.eid
AND tust.stationid=st.stid
AND tust.userid=tu.tuid
AND eua.TYPE=3
AND ev.status=1


UNION ALL
SELECT tu.tuid tuid,tu.tuname tuname, tu.tucode, eua.eid,eua.type,ev.evtype,ev.title,ev.begindate,ev.enddate
from TrainingActivity ta,TrainingActUserFinally tauf ,evaluation ev,evtuserarrange eua ,tuser tu
where eua.eid=ev.eid
and eua.entityid=ta.taid
and ta.state = 1 
and tauf.taid = ta.taid 
and tauf.status = 1 
and tauf.userid = tu.tuid
and eua.type=5
AND ev.status=1

UNION ALL
SELECT tu.tuid tuid,tu.tuname tuname, tu.tucode, eua.eid,eua.type,ev.evtype,ev.title,ev.begindate,ev.enddate
from selectedlesson sl,lesson le,evaluation ev,evtuserarrange eua ,tuser tu
where eua.eid=ev.eid
and eua.entityid=le.leid
and ((eua.type=40 and sl.sltype=0) or (eua.type=41 and sl.sltype=1))
and sl.leid=le.leid
and sl.tuid= tu.tuid
and sl.studystatus=0
AND ev.status=1
/

