create trigger TR_EXAMREGISTERUSER_TYPE
    before insert
    on EAREGISTERUSER
    for each row
    when (new.type = 2 and new.isautoinsert = 0 and new.includechildren = 1)
declare
   deptid number := :new.entityid;
   cursor rs_cursor is
      select tgid from tgroup
      where tgid != deptid
      connect by prior tgid=parentid
      start with tgid = deptid;
    rs rs_cursor%rowtype;
begin
    for rs in rs_cursor
    loop
       insert into earegisteruser (earuid,eaid,entityid,type,includechildren,isautoinsert,id)
       values (:new.earuid,:new.eaid,rs.tgid,2,0,1,:new.earuid);
    end loop;
  
end TR_EXAMREGISTERUSER_TYPE;
/

