create view VTRAININGACTSIGNUP as
SELECT t1.userid,t1.username,t1.tucode,t1.groupids, t1.corpid, t1.entitytype,t1.taid /**
tc.taid, tc.tastartdate, tc.taenddate ,tc.tacode,tc.taname,tc.allowsignup,tc.signupenddate,tc.signupstartdate,tc.allowapprove**/
FROM
(SELECT distinct tu.tuid userid,tu.tuname username,tu.tucode,tu.groupids, tu.corpid, tu.workdate,tau.taid,tau.entitytype
 FROM TrainingActSignUp tau,Tuser tu
 WHERE tau.entityid=tu.tuid AND tau.entitytype=1
 UNION
 SELECT distinct tu.tuid userid,tu.tuname username,tu.tucode,tu.groupids, tu.corpid, tu.workdate,tau.taid,tau.entitytype
 FROM TrainingActSignUp tau,Tuser tu ,tgroup tg
 WHERE tau.entityid = tgid and tg.tgid = tu.deptid and tu.groupids like '%,,'||tg.tgid||',,%'AND tau.entitytype = 2
 UNION
 SELECT distinct tu.tuid userid,tu.tuname username,tu.tucode,tu.groupids, tu.corpid, tu.workdate,tau.taid,tau.entitytype
 FROM TrainingActSignUp tau,Tuser tu, tuserstation ts
 WHERE ts.userid=tu.tuid AND tau.entityID = ts.userid and tau.entitytype=3 ) t1,
 (SELECT taid, tastartdate ,taenddate,tacode,taname,signupenddate, signupstartdate,allowsignup,allowapprove
 FROM trainingactivity ta WHERE ta.state=1 and ta.Allowsignup = 1) tc
WHERE  t1.taid = tc.taid
/

