create trigger DISTRIBUTEACCOUNT_TRI
    before insert
    on DISTRIBUTEACCOUNT
    for each row
declare
tmpvar number ;
begin
 select DISTRIBUTEACCOUNT_SEQ.nextval into tmpvar from dual;
    :new.daid := tmpvar;
end DistributeAccount_tri;
/

