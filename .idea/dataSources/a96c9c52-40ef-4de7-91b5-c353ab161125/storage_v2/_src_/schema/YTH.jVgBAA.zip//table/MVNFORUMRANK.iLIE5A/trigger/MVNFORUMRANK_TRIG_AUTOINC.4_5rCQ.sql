create trigger MVNFORUMRANK_TRIG_AUTOINC
    before insert
    on MVNFORUMRANK
    for each row
begin
  if (:new.RankID is null) then
    select mvnforumRank_seq.nextval into :new.RankID from dual;
  end if;
end;
/

