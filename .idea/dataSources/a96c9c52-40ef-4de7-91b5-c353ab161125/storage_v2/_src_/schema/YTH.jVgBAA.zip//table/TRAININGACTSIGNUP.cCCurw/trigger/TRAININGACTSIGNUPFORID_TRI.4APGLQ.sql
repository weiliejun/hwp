create trigger TRAININGACTSIGNUPFORID_TRI
    before insert
    on TRAININGACTSIGNUP
    for each row
declare
tmpvar number ;
begin
 select DISTRIBUTEACCOUNT_SEQ.nextval into tmpvar from dual;
    :new.tasuid := tmpvar;
end TrainingActSignUpForID_tri;
/

