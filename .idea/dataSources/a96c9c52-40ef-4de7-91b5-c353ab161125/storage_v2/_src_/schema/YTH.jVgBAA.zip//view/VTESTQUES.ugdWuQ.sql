create view VTESTQUES as
select tq.tqid, tq.tqnum, tq.typeid, tq.difficulty, tq.content, tq.quesimage, tq.answimage,
tq.time, tq.score, tq.reader, tq.readertime, tq.eligibility, tq.realdifficulty,
tq.realdifference, tq.difference, tq.cognize, tq.simques, tq.detailans,
tq.rtids, tq.optionsnum, rb.rbid, rb.kcid, rb.rtid, rb.tgid, rb.title,
rb.identifier,  rb.description,  rb.keyword,
rb.creator, rb.toll, rb.publisher, rb.publishdate,
rb.language, rb.audience, rb.isopen, rb.issuestatus,
rb.usetimes, rb.scantimes, rb.creatorid, rb.createtime, 0 shareresource, rb.tgid usetgid
from resourcebasic rb, testques tq
where rb.rbid = tq.tqid
union
select tq.tqid, tq.tqnum, tq.typeid, tq.difficulty, tq.content, tq.quesimage, tq.answimage,
tq.time, tq.score, tq.reader, tq.readertime, tq.eligibility, tq.realdifficulty,
tq.realdifference, tq.difference, tq.cognize, tq.simques, tq.detailans,
tq.rtids, tq.optionsnum, rb.rbid, rb.kcid, rb.rtid, rb.tgid, rb.title,
rb.identifier, rb.description, rb.keyword,
rb.creator, rb.toll, rb.publisher, rb.publishdate,
rb.language, rb.audience, rb.isopen, rb.issuestatus,
rb.usetimes, rb.scantimes, rb.creatorid, rb.createtime, 1 shareresource, rd.tgid usetgid
from resourcebasic rb, testques tq, resourcedistribution rd
where rb.rbid = tq.tqid and rb.rbid = rd.rbid and rb.rtid = 9004 and rb.issuestatus = 1


/

