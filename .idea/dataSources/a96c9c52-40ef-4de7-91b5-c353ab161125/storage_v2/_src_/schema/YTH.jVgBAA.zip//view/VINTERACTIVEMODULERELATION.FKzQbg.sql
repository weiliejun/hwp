create view VINTERACTIVEMODULERELATION as
SELECT ta.taid,ta.tacode,t1.imrid,t1.imrcode,t1.imrname,t1.entitytype,t1.state,t1.entityid
FROM
(
    SELECT ta.taid,mff.forumname as imrname,mff.forumname as imrcode,imr.entitytype,imr.state,imr.entityid,imr.imrid
    FROM trainingactivity ta,InteractiveModuleRelation imr,mvnforumforum mff
    WHERE ta.taid = imr.taid and imr.entitytype = 1 and imr.entityid = mff.forumid
    UNION all
    SELECT ta.taid,see.seename as imrname,see.seecode as imrcode,imr.entitytype,imr.state,imr.entityid,imr.imrid
    FROM trainingactivity ta,InteractiveModuleRelation imr,ServerEventEntity see
    WHERE ta.taid = imr.taid and imr.entitytype = 2 and imr.entityid = see.seeid
    UNION all
    SELECT ta.taid,rrp.title as imrname,rrp.rrpcode as imrcode,imr.entitytype,imr.state,imr.entityid,imr.imrid
    FROM trainingactivity ta,InteractiveModuleRelation imr,RequireResearchPaper rrp
    WHERE ta.taid = imr.taid and imr.entitytype = 3 and imr.entityid = rrp.rrpid
) t1,trainingactivity ta where ta.taid = t1.taid
/

