create trigger MVNFORUMMESSAGE_TRIG_AUTOINC
    before insert
    on MVNFORUMMESSAGE
    for each row
begin
  if (:new.MessageID is null) then
    select mvnforumMessage_seq.nextval into :new.MessageID from dual;
  end if;
end;
/

