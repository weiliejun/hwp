create trigger TRAININGACTSIGNUP_TRI
    before insert
    on TRAININGACTSIGNUP
    for each row
    when (new.EntityType = 2 and new.isAutomatism = 0 and new.IncludeChildrenDept = 1)
declare
/******************************************************************************
   NAME:       TrainingActSignUp_tri
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2007-7-20   zhaoyuayang      1. Created this trigger.

   NOTES:增加培训活动中报名培训班的机构下的子机构


******************************************************************************/
   tempTgidVar number :=0;        --存储机构id的变量。用来判断是否是已经存在的机构
   deptid number := :new.entityid;
   cursor rs_cursor is
      select tgid from tgroup where tgid != deptid connect by prior tgid=parentid start with tgid = deptid;
    rs rs_cursor%rowtype;
begin
    for rs in rs_cursor
    loop
        select count(tasu.entityid) into tempTgidVar from TrainingActSignUp tasu where tasu.entityid = rs.tgid 
        and tasu.entitytype = 2 and tasu.taid = :new.taid;
        if(tempTgidVar = 0) then
             insert into TrainingActSignUp (taid,entitytype,entityid,isautomatism,creatorid,createtime)
             values (:new.taid,2,rs.tgid,1,:new.creatorid,:new.createtime);
        end if;
    end loop;

      
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
    NULL;
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('error='||sqlcode||',sqlerrm='||sqlerrm);
   rollback;
end;
/

