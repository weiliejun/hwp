create trigger MVNFORUMPOST_TRIG_AUTOINC
    before insert
    on MVNFORUMPOST
    for each row
begin
  if (:new.PostID is null) then
    select mvnforumPost_seq.nextval into :new.PostID from dual;
  end if;
end;
/

