create trigger MVNFORUMPMATTACH_TRIG_AUTOINC
    before insert
    on MVNFORUMPMATTACHMENT
    for each row
begin
  if (:new.PmAttachID is null) then
    select mvnforumPmAttachment_seq.nextval into :new.PmAttachID from dual;
  end if;
end;
/

