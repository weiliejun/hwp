create function getAnswer(id in varchar2) return varchar2 is
   idid varchar(2000);

ind number := 1;
iii number := -1;
fid varchar2(2000) := '';
bid varchar2(2000) := '';
eName varchar(2000) := '';
begin
bid := id || ',';
iii := instr(bid, ',', ind);
while(iii > 0)
  loop
 fid := substr(bid, ind, iii - ind);
 select t.Optiontext INTO eName from requireresearchtestquesanswer t where t.rrtqaid = fid;
 if(ind = 1) then
   idid := eName;
 else
   idid := idid || ';' || eName;
    end if;
 ind := iii + 1;
 iii := instr(bid, ',', ind);
  end loop;

  return(idid);
end getAnswer;
/

