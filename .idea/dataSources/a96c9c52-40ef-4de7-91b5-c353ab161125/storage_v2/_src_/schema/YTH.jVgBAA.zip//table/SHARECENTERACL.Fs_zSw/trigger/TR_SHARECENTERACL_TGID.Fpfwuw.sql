create trigger TR_SHARECENTERACL_TGID
    before insert
    on SHARECENTERACL
    for each row
    when (new.tgidtype = 2 and new.isautomatism = 0 and new.includechildren = 1)
declare
   deptid number := :new.tgid;
   cursor rs_cursor is
      select tgid from tgroup
      where tgid != deptid
      connect by prior tgid=parentid
      start with tgid = deptid;
    rs rs_cursor%rowtype;
begin
    for rs in rs_cursor
    loop
       insert into sharecenteracl (SCACALID,RTID,TGID,INCLUDECHILDREN,ISAUTOMATISM,CREATORID,CREATETIME,TGIDTYPE)
       values (:new.scacalid,:new.rtid,rs.tgid,0,1,:new.creatorid,:new.createtime,:new.tgidtype);
    end loop;

end TR_SHARECENTERACL_TGID;


/

