create trigger TR_EXAMARRANGEUSER_TYPE
    before insert
    on EXAMARRANGEUSER
    for each row
    when (new.type = 2 and new.isautoinsert = 0 and new.includechildren = 1)
declare
   deptid number := :new.entityid;
   cursor rs_cursor is
      select tgid from tgroup
      where tgid != deptid
      connect by prior tgid=parentid
      start with tgid = deptid;
    rs rs_cursor%rowtype;
begin
    for rs in rs_cursor
    loop
       insert into examarrangeuser (eauid,eaid,entityid,type,includechildren,isautoinsert,id)
       values (:new.eauid,:new.eaid,rs.tgid,2,0,1,:new.entityid);
    end loop;
  
end TR_EXAMARRANGEUSER_TYPE;
/

