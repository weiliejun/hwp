create trigger MVNFORUMCATEGORY_TRIG_AUTOINC
    before insert
    on MVNFORUMCATEGORY
    for each row
begin
  if (:new.CategoryID is null) then
    select mvnforumCategory_seq.nextval into :new.CategoryID from dual;
  end if;
end;
/

