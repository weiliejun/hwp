create trigger MVNFORUMMEMBER_TRIG_AUTOINC
    before insert
    on MVNFORUMMEMBER
    for each row
begin
  if (:new.MemberID is null) then
    select mvnforumMember_seq.nextval into :new.MemberID from dual;
  end if;
end;
/

