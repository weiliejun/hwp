create trigger MVNFORUMTHREAD_TRIG_AUTOINC
    before insert
    on MVNFORUMTHREAD
    for each row
begin
  if (:new.ThreadID is null) then
    select mvnforumThread_seq.nextval into :new.ThreadID from dual;
  end if;
end;
/

