create PROCEDURE saveClassroomUserFromTrainUser
(taid number,seeid number,othermodeltype number,creatorid number,createtime varchar2) as

/******************************************************************************
   NAME:       saveClassroomUserFromTrainUser
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2008-1-17   zhaoyuyang       1. Created this procedure.

   NOTES: ？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？

******************************************************************************/


--？α？4 ？？？？？？？？？？？？？？？？？
    cursor rs_cursor4 is
           select tauf.taufid,tauf.taid,tauf.userid from TrainingActUserFinally tauf where tauf.taid = taid and tauf.status = 1;
    rs4 rs_cursor4%rowtype;


BEGIN

        for rs4 in rs_cursor4
           loop

                     INSERT INTO Servereventuserfinally
                     (seeid,tuid,entitytypeids,othermodelid,othermodeltype,creatorid,createtime)
                     values
                     (seeid,rs4.userid,'@A_'||rs4.userid,taid,othermodeltype,creatorid,createtime);

         end loop;
        /

