create view VCASES as
select case.caseid, case.casenum, case.remark, case.casemakemethod, case.maincontent, case.rtids, case.studydays,
rb.rbid, rb.kcid, rb.rtid, rb.tgid, rb.title,
rb.identifier, rb.description, rb.keyword,
rb.creator, rb.toll, rb.publisher, rb.publishdate,
rb.language, rb.audience, rb.isopen, rb.issuestatus,
rb.usetimes, rb.scantimes, rb.creatorid, rb.createtime, 0 shareresource, rb.tgid usetgid
from cases case, resourcebasic rb where case.caseid = rb.rbid
union
select case.caseid, case.casenum, case.remark, case.casemakemethod, case.maincontent, case.rtids, case.studydays,
rb.rbid, rb.kcid, rb.rtid, rb.tgid, rb.title,
rb.identifier, rb.description, rb.keyword,
rb.creator, rb.toll, rb.publisher, rb.publishdate,
rb.language, rb.audience, rb.isopen, rb.issuestatus,
rb.usetimes, rb.scantimes, rb.creatorid, rb.createtime, 1 shareresource, rd.tgid usetgid
from cases case, resourcebasic rb, resourcedistribution rd
where case.caseid = rb.rbid and rb.rbid = rd.rbid and rd.rtid = 9003 and rb.issuestatus = 1


/

