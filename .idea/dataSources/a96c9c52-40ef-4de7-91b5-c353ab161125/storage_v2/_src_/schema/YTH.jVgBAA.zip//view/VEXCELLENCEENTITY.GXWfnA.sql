create view VEXCELLENCEENTITY as
select ee.eeid ,ee.entityid ,ee.entitytype ,ee.eeindex ,ee.remark ,ee.creatorid ,ee.createtime ,ee.eecomment,tu.tuname as name,tu.tucode as code
from Excellenceentity ee,tuser tu
where ee.entityid = tu.tuid and ee.entitytype = 1
UNION
select ee.eeid ,ee.entityid ,ee.entitytype ,ee.eeindex ,ee.remark ,ee.creatorid ,ee.createtime ,ee.eecomment,tu.tuname as name,tu.tucode as code
from Excellenceentity ee,tuser tu ,teacher tea
where ee.entityid = tu.tuid and ee.entitytype = 3 and tea.tuid = tu.tuid
UNION
select ee.eeid ,ee.entityid ,ee.entitytype ,ee.eeindex ,ee.remark ,ee.creatorid ,ee.createtime ,ee.eecomment,tg.tgname as name,tg.tgcode as code
from Excellenceentity ee,tgroup tg
where ee.entityid = tg.tgid and ee.entitytype = 2
UNION
select ee.eeid ,ee.entityid ,ee.entitytype ,ee.eeindex ,ee.remark ,ee.creatorid ,ee.createtime ,ee.eecomment,ta.taname as name,ta.tacode as code
from Excellenceentity ee,trainingactivity ta
where ee.entityid = ta.taid and ee.entitytype = 4
UNION
select ee.eeid ,ee.entityid ,ee.entitytype ,ee.eeindex ,ee.remark ,ee.creatorid ,ee.createtime ,ee.eecomment,le.lename as name,le.lecode as code
from Excellenceentity ee,lesson le
where ee.entityid = le.leid and ee.entitytype = 5
/

