create procedure mtn_rebuild_all_idx

as

cursor indexCursor is

select * from user_indexes where table_owner='YTHEL' and
index_type='NORMAL';

indexRow indexCursor%ROWTYPE;

sqlText varchar2(1024);

begin

open indexCursor;

loop

fetch indexCursor into indexRow;

exit when indexCursor%NOTFOUND;

sqlText :=' alter index ' || indexRow.index_name || ' rebuild ';

BEGIN

execute immediate (sqlText);

insert into tmMTNLog(fLogDate,fLogMsg) values( sysdate,'rebuild
index success:' || indexRow.index_name);

EXCEPTION

WHEN OTHERS THEN

insert into tmMTNLog(fLogDate,fLogMsg) values( sysdate,
'rebuild index fail:' || indexRow.index_name);

END;

end loop;

end;
/

