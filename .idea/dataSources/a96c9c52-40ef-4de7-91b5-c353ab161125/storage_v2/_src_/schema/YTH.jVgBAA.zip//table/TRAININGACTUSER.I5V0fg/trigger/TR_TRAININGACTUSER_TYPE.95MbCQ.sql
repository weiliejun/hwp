create trigger TR_TRAININGACTUSER_TYPE
    before insert
    on TRAININGACTUSER
    for each row
declare
/******************************************************************************
   NAME:       tr_trainingactuser_type
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2007-7-20   zhaoyuayang      1. Created this trigger.

   NOTES:执行培训活动中增加机构和岗位下的人


******************************************************************************/
 entityidVar number := :new.entityid;    --当前的实体id
 typeVar number := :new.type;        --当前的实体类型
 includechildrenVar number := :new.includechildren;         --是否包含子机构
 taidVar number := :new.taid;        --培训活动id
 tempUseridVar number :=0;        --存储人员id的变量。用来判断是否是已经存在的人员
 tempSeeUseridVar number :=0;        --存储人员id的变量。用来判断培训活动生成的同步事件中是否已经插入此培训活动的人

 
 cursor rs_cursor1 is
        select deptid,tuid from tuser where deptid = entityidVar;
 rs1 rs_cursor1%rowtype;
 
 cursor rs_cursor2 is
        --select deptid,tuid from tuser where groupids like '%,,'||entityidVar||',,%';
        select deptid,tuid from tuser,(SELECT tgid FROM tgroup CONNECT BY PRIOR tgid = parentid START WITH tgid = entityidVar) tg 
        where tuser.deptid = tg.tgid;
 rs2 rs_cursor2%rowtype;
 
 cursor rs_cursor3 is
        select tu.deptid,tu.tuid,ts.stationid from tuser tu,tuserstation ts 
        where tu.tuid = ts.userid and ts.stationid = entityidVar;
 rs3 rs_cursor3%rowtype;
 
 cursor rs_cursor4 is
        select imr.entityid from InteractiveModuleRelation imr  where imr.entitytype = 2 and taid = taidVar;
 rs4 rs_cursor4%rowtype;
 
Begin
if(typeVar!=1) then --插入人员不触发
   if(typeVar=3) then --插入岗位人员
      for rs3 in rs_cursor3
             
          
          loop
             select count(tauf.userid) into tempUseridVar from TrainingActUserFinally tauf where tauf.taid = taidVar and tauf.userid = rs3.tuid;
             if  (tempUseridVar = 0) then
                 insert into TrainingActUserFinally (taid,userid,entitytypeids,tgid,isautomatism,creatorid,createtime)
                 values(:new.taid,rs3.tuid,'@C_'||rs3.stationid,rs3.deptid,0,:new.creatorid,:new.createtime);
             
             else
                              
                 update TrainingActUserFinally tauf set  tauf.status = 1,entitytypeids = entitytypeids || ('@C_'||rs3.stationid) 
                 where tauf.taid = taidVar and tauf.userid = rs3.tuid;
                 
             end if;
             
             /**
             这里增加游标rs4的处理是为了同步，培训活动下创建的同步事件人员
             **/
             for rs4 in rs_cursor4
                 loop
                     select count(seuf.tuid) into tempSeeUseridVar from ServerEventUserFinally seuf 
                     where seuf.othermodelid = taidVar and seuf.othermodeltype = 2 and seuf.tuid = rs3.tuid and seuf.seeid = rs4.entityid;
                     
                     if(tempSeeUseridVar = 0) then
                     
                       INSERT INTO Servereventuserfinally 
                       (seeid,tuid,entitytypeids,othermodelid,othermodeltype,creatorid,createtime) 
                       values (rs4.entityid,rs3.tuid,'@A_'||rs3.tuid,taidVar,2,:new.creatorid,:new.createtime);
                   
                     end if;
                 end loop;
             
          end loop;
   else
   
     if(typeVar=2 and includechildrenVar = 1) then --插入包含子机构的人员
     
          for rs2 in rs_cursor2
             
          
          loop
              select count(tauf.userid) into tempUseridVar from TrainingActUserFinally tauf where tauf.taid = taidVar and tauf.userid = rs2.tuid;
             if  (tempUseridVar = 0) then
                 insert into TrainingActUserFinally (taid,userid,entitytypeids,tgid,isautomatism,creatorid,createtime)
                 values(:new.taid,rs2.tuid,'@B_'||entityidVar,rs2.deptid,1,:new.creatorid,:new.createtime);
             
             else
                              
                 update TrainingActUserFinally tauf set  tauf.status = 1,entitytypeids = entitytypeids || ('@B_'||entityidVar) 
                 where tauf.taid = taidVar and tauf.userid = rs2.tuid;
                 
             end if;
             
             
             /**
             这里增加游标rs4的处理是为了同步，培训活动下创建的同步事件人员
             **/
             for rs4 in rs_cursor4
                 loop
                     select count(seuf.tuid) into tempSeeUseridVar from ServerEventUserFinally seuf 
                     where seuf.othermodelid = taidVar and seuf.othermodeltype = 2 and seuf.tuid = rs2.tuid and seuf.seeid = rs4.entityid;
                     
                     if(tempSeeUseridVar = 0) then
                     
                       INSERT INTO Servereventuserfinally 
                       (seeid,tuid,entitytypeids,othermodelid,othermodeltype,creatorid,createtime) 
                       values (rs4.entityid,rs2.tuid,'@A_'||rs2.tuid,taidVar,2,:new.creatorid,:new.createtime);
                   
                     end if;
                 end loop;
                 
          end loop;
                                     
     else  --插入包不含子机构的人员
          for rs1 in rs_cursor1
             
          
          loop
              select count(tauf.userid) into tempUseridVar from TrainingActUserFinally tauf where tauf.taid = taidVar and tauf.userid = rs1.tuid;
             if  (tempUseridVar = 0) then
                 insert into TrainingActUserFinally (taid,userid,entitytypeids,tgid,isautomatism,creatorid,createtime)
                 values(:new.taid,rs1.tuid,'@B_'||entityidVar,rs1.deptid,0,:new.creatorid,:new.createtime);
             
             else
                              
                 update TrainingActUserFinally tauf set  tauf.status = 1,entitytypeids = entitytypeids || ('@B_'||entityidVar) 
                 where tauf.taid = taidVar and tauf.userid = rs1.tuid;
                 
             end if;
             
             
             /**
             这里增加游标rs4的处理是为了同步，培训活动下创建的同步事件人员
             **/
             for rs4 in rs_cursor4
                 loop
                     select count(seuf.tuid) into tempSeeUseridVar from ServerEventUserFinally seuf 
                     where seuf.othermodelid = taidVar and seuf.othermodeltype = 2 and seuf.tuid = rs1.tuid and seuf.seeid = rs4.entityid;
                     
                     if(tempSeeUseridVar = 0) then
                     
                       INSERT INTO Servereventuserfinally 
                       (seeid,tuid,entitytypeids,othermodelid,othermodeltype,creatorid,createtime) 
                       values (rs4.entityid,rs1.tuid,'@A_'||rs1.tuid,taidVar,2,:new.creatorid,:new.createtime);
                   
                     end if;
                 end loop;
          end loop;
                  
     end if;

   end if; 
end if;
end;
/

