create trigger TRAININGACTUSERFINALLY_TRI
    before insert
    on TRAININGACTUSERFINALLY
    for each row
declare
tmpvar number ;
begin
 select DISTRIBUTEACCOUNT_SEQ.nextval into tmpvar from dual;
    :new.taufid := tmpvar;
end TrainingActUserFinally_tri;
/

