create trigger MVNFORUMWATCH_TRIG_AUTOINC
    before insert
    on MVNFORUMWATCH
    for each row
begin
  if (:new.WatchID is null) then
    select mvnforumWatch_seq.nextval into :new.WatchID from dual;
  end if;
end;
/

