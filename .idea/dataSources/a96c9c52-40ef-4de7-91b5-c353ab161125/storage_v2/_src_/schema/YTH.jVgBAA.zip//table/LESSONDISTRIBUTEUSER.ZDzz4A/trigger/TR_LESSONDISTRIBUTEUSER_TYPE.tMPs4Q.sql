create trigger TR_LESSONDISTRIBUTEUSER_TYPE
    before insert
    on LESSONDISTRIBUTEUSER
    for each row
declare
/******************************************************************************
   NAME:       tr_LessonDistributeUser_type
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2007-7-20   zhaoyuayang      1. Created this trigger.

   NOTES:执行课程分配中增加机构和岗位下的人


******************************************************************************/
 entityidVar number := :new.entityid;    --当前的实体id
 typeVar number := :new.type;        --当前的实体类型
 includechildrenVar number := :new.includechildren;         --是否包含子机构
 ldidVar number := :new.ldid;        --培训活动id
 tempUseridVar number :=0;        --存储人员id的变量。用来判断是否是已经存在的人员

 
 cursor rs_cursor1 is
        select deptid,tuid from tuser where deptid = entityidVar;
 rs1 rs_cursor1%rowtype;
 
 cursor rs_cursor2 is
        select deptid,tuid from tuser where groupids like '%,,'||entityidVar||',,%';
 rs2 rs_cursor2%rowtype;
 
 cursor rs_cursor3 is
        select tu.deptid,tu.tuid,ts.stationid from tuser tu,tuserstation ts 
        where tu.tuid = ts.userid and ts.stationid = entityidVar;
 rs3 rs_cursor3%rowtype;
 
begin
   if(typeVar=3) then --插入岗位人员
      for rs3 in rs_cursor3
             
          
          loop
             select count(tauf.userid) into tempUseridVar from LessonDistributeUserFinally tauf where tauf.ldid = ldidVar and tauf.userid = rs3.tuid;
             if  (tempUseridVar = 0) then
                 insert into LessonDistributeUserFinally (ldid,userid,entitytypeids,tgid,isautomatism,creatorid,createtime)
                 values(:new.ldid,rs3.tuid,'@C_'||rs3.stationid,rs3.deptid,1,:new.creatorid,:new.createtime);
             
             else
                              
                 update LessonDistributeUserFinally tauf set entitytypeids = entitytypeids || ('@C_'||rs3.stationid) 
                 where tauf.ldid = ldidVar and tauf.userid = rs3.tuid;
                 
             end if;
             
          end loop;
   else
   
     if(typeVar=2 and includechildrenVar = 1) then --插入包含子机构的人员
     
          for rs2 in rs_cursor2
             
          
          loop
              select count(tauf.userid) into tempUseridVar from LessonDistributeUserFinally tauf where tauf.ldid = ldidVar and tauf.userid = rs2.tuid;
             if  (tempUseridVar = 0) then
                 insert into LessonDistributeUserFinally (ldid,userid,entitytypeids,tgid,isautomatism,creatorid,createtime)
                 values(:new.ldid,rs2.tuid,'@B_'||entityidVar,rs2.deptid,1,:new.creatorid,:new.createtime);
             
             else
                              
                 update LessonDistributeUserFinally tauf set entitytypeids = entitytypeids || ('@B_'||entityidVar) 
                 where tauf.ldid = ldidVar and tauf.userid = rs2.tuid;
                 
             end if;
          end loop;
                                     
     else  --插入包不含子机构的人员
          for rs1 in rs_cursor1
             
          
          loop
              select count(tauf.userid) into tempUseridVar from LessonDistributeUserFinally tauf where tauf.ldid = ldidVar and tauf.userid = rs1.tuid;
             if  (tempUseridVar = 0) then
                 insert into LessonDistributeUserFinally (ldid,userid,entitytypeids,tgid,isautomatism,creatorid,createtime)
                 values(:new.ldid,rs1.tuid,'@B_'||entityidVar,rs1.deptid,1,:new.creatorid,:new.createtime);
             
             else
                              
                 update LessonDistributeUserFinally tauf set entitytypeids = entitytypeids || ('@B_'||entityidVar) 
                 where tauf.ldid = ldidVar and tauf.userid = rs1.tuid;
                 
             end if;
          end loop;
                  
     end if;

   end if; 

end;
/

