create trigger LESSONDISTRIBUTEUSER_TRI
    before insert
    on LESSONDISTRIBUTEUSER
    for each row
declare
tmpvar number ;
begin
 select DISTRIBUTEACCOUNT_SEQ.nextval into tmpvar from dual;
    :new.lduid := tmpvar;
end LessonDistributeUser_tri;
/

