create trigger MVNFORUMATTACH_TRIG_AUTOINC
    before insert
    on MVNFORUMATTACHMENT
    for each row
begin
  if (:new.AttachID is null) then
    select mvnforumAttachment_seq.nextval into :new.AttachID from dual;
  end if;
end;
/

