create view VLESSON as
select le.leid, le.lecode, le.lename, le.trainingtype, le.fee, le.allowday, le.mark,
le.hour, le.isselftest, le.selftestnum, le.remark, le.selfnavigator, le.enterurl,
le.traintarget, le.traincomment, le.trainmanner, le.isoffline, le.handbacktime,
le.ispermitpreview, le.coursewareprovider, le.isawardcert, le.lessionaim, le.coursewareregion,
le.isautodownload, le.coursetype, le.coursestandard, le.coursemakemethod, le.certmodelid,
le.rtids, le.strategy , rb.rbid, rb.kcid, rb.rtid, rb.tgid, rb.title, rb.identifier,
rb.description, rb.keyword, rb.creator, rb.toll, rb.publisher, rb.publishdate, rb.language,
rb.audience, rb.isopen, rb.issuestatus, rb.usetimes, rb.scantimes, rb.creatorid, rb.createtime, 0 shareresource, rb.tgid usetgid
from lesson le,resourcebasic rb where le.leid = rb.rbid
union
select le.leid, le.lecode, le.lename, le.trainingtype, le.fee, le.allowday, le.mark,
le.hour, le.isselftest, le.selftestnum, le.remark, le.selfnavigator, le.enterurl,
le.traintarget, le.traincomment, le.trainmanner, le.isoffline, le.handbacktime,
le.ispermitpreview, le.coursewareprovider, le.isawardcert, le.lessionaim, le.coursewareregion,
le.isautodownload, le.coursetype, le.coursestandard, le.coursemakemethod, le.certmodelid,
le.rtids, le.strategy , rb.rbid, rb.kcid, rb.rtid, rb.tgid, rb.title, rb.identifier,
rb.description, rb.keyword, rb.creator, rb.toll, rb.publisher, rb.publishdate, rb.language,
rb.audience, rb.isopen, rb.issuestatus, rb.usetimes, rb.scantimes, rb.creatorid, rb.createtime, 1 shareresource, rd.tgid usetgid
from lesson le, resourcebasic rb, resourcedistribution rd
where le.leid = rb.rbid and rd.rbid = le.LEID and rd.rtid = 9001 and rb.issuestatus = 1


/

