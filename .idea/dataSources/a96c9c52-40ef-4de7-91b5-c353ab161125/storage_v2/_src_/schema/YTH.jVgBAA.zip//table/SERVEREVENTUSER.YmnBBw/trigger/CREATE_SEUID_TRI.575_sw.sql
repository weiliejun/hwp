create trigger CREATE_SEUID_TRI
    before insert
    on SERVEREVENTUSER
    for each row
declare
tmpvar number ;
begin
 select DISTRIBUTEACCOUNT_SEQ.nextval into tmpvar from dual;
    :new.seuid := tmpvar;
end create_seuid_tri;
/

