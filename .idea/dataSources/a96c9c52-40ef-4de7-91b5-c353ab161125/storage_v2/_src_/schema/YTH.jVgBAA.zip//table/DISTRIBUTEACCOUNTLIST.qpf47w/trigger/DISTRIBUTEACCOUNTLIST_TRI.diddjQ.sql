create trigger DISTRIBUTEACCOUNTLIST_TRI
    before insert
    on DISTRIBUTEACCOUNTLIST
    for each row
declare
tmpvar number ;
begin
 select DISTRIBUTEACCOUNT_SEQ.nextval into tmpvar from dual;
    :new.dalid := tmpvar;
end Distributeaccountlist_tri;
/

