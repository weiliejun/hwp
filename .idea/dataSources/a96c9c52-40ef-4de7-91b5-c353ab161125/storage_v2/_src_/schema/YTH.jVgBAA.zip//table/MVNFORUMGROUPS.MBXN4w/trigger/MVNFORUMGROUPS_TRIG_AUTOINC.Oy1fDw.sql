create trigger MVNFORUMGROUPS_TRIG_AUTOINC
    before insert
    on MVNFORUMGROUPS
    for each row
begin
  if (:new.GroupID is null) then
    select mvnforumGroups_seq.nextval into :new.GroupID from dual;
  end if;
end;
/

