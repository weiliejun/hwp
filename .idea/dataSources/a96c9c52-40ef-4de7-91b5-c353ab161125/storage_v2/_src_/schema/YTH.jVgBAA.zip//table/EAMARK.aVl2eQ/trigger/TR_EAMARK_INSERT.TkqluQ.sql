create trigger TR_EAMARK_INSERT
    before insert
    on EAMARK
    for each row
declare
  sequnceValue number ;
begin
   select EAMARK_SEQ.NEXTVAL into sequnceValue from dual;
   :new.eamkid := sequnceValue;
end TR_EAMARK_INSERT;
/

