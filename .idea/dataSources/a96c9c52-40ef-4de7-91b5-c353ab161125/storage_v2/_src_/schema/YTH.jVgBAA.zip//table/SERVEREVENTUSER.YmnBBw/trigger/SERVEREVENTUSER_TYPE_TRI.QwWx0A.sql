create trigger SERVEREVENTUSER_TYPE_TRI
    before insert
    on SERVEREVENTUSER
    for each row
declare
/******************************************************************************
   NAME:       servereventuser_type_tri
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2008-1-18   zhaoyuyang      1. Created this trigger.

   NOTES:执行同步事件中增加机构的人


******************************************************************************/
 entityidVar number := :new.entityid;    --当前的实体id
 typeVar number := :new.type;        --当前的实体类型
 includechildrenVar number := :new.includechildren;         --是否包含子机构
 seeidVar number := :new.seeid;        --同步事件id
 tempUseridVar number :=0;        --存储人员id的变量。用来判断是否是已经存在的人员

 
 cursor rs_cursor1 is
        select deptid,tuid from tuser where deptid = entityidVar;
 rs1 rs_cursor1%rowtype;
 
 cursor rs_cursor2 is
        select deptid,tuid from tuser where deptid in 
        (select tgid from tgroup  connect by prior tgid = parentid  start with tgid = entityidVar);
 rs2 rs_cursor2%rowtype;
 
begin

     if(typeVar=2 and includechildrenVar = 1) then --插入包含子机构的人员
     
          for rs2 in rs_cursor2
             
          
          loop
              select count(seuf.tuid) into tempUseridVar from Servereventuserfinally seuf where seuf.seeid = seeidVar and seuf.tuid = rs2.tuid;
             if  (tempUseridVar = 0) then
                 insert into Servereventuserfinally (seeid,tuid,entitytypeids,creatorid,createtime)
                 values(:new.seeid,rs2.tuid,'@B_'||entityidVar,:new.creatorid,:new.createtime);
             
             else
                              
                 update Servereventuserfinally seuf set entitytypeids = entitytypeids || ('@B_'||entityidVar) 
                 where seuf.seeid = seeidVar and seuf.tuid = rs2.tuid;
                 
                 /**
                 这个更新语句作用：
                 同步事件的最终人员可能是从其它模块的人员表里筛选出来的
                 （例如：培训活动增加同步课堂组件，这时这个同步课堂的人员来自培训活动的最终人员表)
                 这时将这两个字段更新 ：othermodelid = null,othermodeltype = 1 。将此人更新成直接指定的人员
                 **/
                 update Servereventuserfinally seuf set othermodelid = null,othermodeltype = 1  
                 where seuf.seeid = seeidVar and seuf.tuid = rs2.tuid and othermodeltype = 2;
                 
             end if;
          end loop;
                                     
     else  --插入包不含子机构的人员
          for rs1 in rs_cursor1
             
          
          loop
              select count(seuf.tuid) into tempUseridVar from Servereventuserfinally seuf where seuf.seeid = seeidVar and seuf.tuid = rs1.tuid;
             if  (tempUseridVar = 0) then
                 insert into Servereventuserfinally (seeid,tuid,entitytypeids,creatorid,createtime)
                 values(:new.seeid,rs1.tuid,'@B_'||entityidVar,:new.creatorid,:new.createtime);
             
             else
                              
                 update Servereventuserfinally seuf set entitytypeids = entitytypeids || ('@B_'||entityidVar) 
                 where seuf.seeid = seeidVar and seuf.tuid = rs1.tuid;
                 
                 /**
                 这个更新语句作用：
                 同步事件的最终人员可能是从其它模块的人员表里筛选出来的
                 （例如：培训活动增加同步课堂组件，这时这个同步课堂的人员来自培训活动的最终人员表)
                 这时将这两个字段更新 ：othermodelid = null,othermodeltype = 1 。将此人更新成直接指定的人员
                 **/
                 update Servereventuserfinally seuf set othermodelid = null,othermodeltype = 1  
                 where seuf.seeid = seeidVar and seuf.tuid = rs1.tuid and othermodeltype = 2;
                 
             end if;
          end loop;
                  
     end if;

end;
/

