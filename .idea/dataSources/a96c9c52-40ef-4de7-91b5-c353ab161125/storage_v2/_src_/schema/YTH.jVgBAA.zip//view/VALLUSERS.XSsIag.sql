create view VALLUSERS as
(select tub.tuid,tub.tucode,tub.tuname,tub.deptid,tub.groupids from tuserbak tub)
union all
(select tu.tuid,tu.tucode,tu.tuname,tu.deptid,tu.groupids from tuser tu)


/

