create view VREQUIRERESEARCHUSER as
SELECT rrs.entityid tuid,tu.tuname tuname, tu.tucode, rrh.rrpid
FROM requireresearchpaper rrh,requireresearchstudent rrs ,TUSER tu
WHERE rrs.entityID=tu.tuid
AND rrh.rrpid=rrs.rrpid
AND rrs.TYPE=1

UNION
SELECT distinct tu.tuid tuid,tu.tuname tuname, tu.tucode, rrh.rrpid
FROM requireresearchpaper rrh,requireresearchstudent rrs ,TUSER tu ,TGROUP tg
WHERE rrs.entityid = tg.tgid
AND rrs.rrpid=rrh.rrpid
AND tu.groupids  like ',,%'||tg.tgid||'%,,'
AND rrs.TYPE=2

UNION
SELECT distinct tu.tuid tuid,tu.tuname tuname, tu.tucode, rrh.rrpid
FROM requireresearchpaper rrh,requireresearchstudent rrs ,TUSER tu ,STATION st,tuserstation tust
WHERE rrs.entityid = st.stid
AND rrs.rrpid=rrh.rrpid
AND tust.stationid=st.stid
AND rrs.TYPE=3
/

